#ifndef RMA_COMMON
#define RMA_COMMON 1

int sort_double(const double *a1,const double *a2);
double  median(double *x, int length);
double  median_nocopy(double *x, int length);



#endif
