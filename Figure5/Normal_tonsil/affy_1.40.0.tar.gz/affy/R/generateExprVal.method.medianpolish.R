generateExprVal.method.medianpolish <- function(probes, ...) 
  medianpolish(probes, ...)

